#!/usr/bin/env python2.7

import sys, os, glob
import argparse

def get_args(args):

	indir = args.input[0]

	if not indir.endswith("/"):
		indir = indir + "/"

	outdir = args.output[0]

	if not outdir.endswith("/"):
		outdir = outdir + "/"

	return(indir, outdir)

def glob_files(indir, outdir):

	vind = ["Hit #","Virulence Gene Name","E-Value Percent (%) Identity","Percent (%) Coverage"]
	aind = ["Hit #","AMR Gene Name","E-Value Percent (%) Identity","Percent (%) Coverage"]
	vtask, atask = 0, 0
	filelist = []
	vlist, alist = [], []
	for f in glob.glob(indir + "*_final_results.txt"):
		filelist.append(f)
		infile = open(f, "r")
		for line in infile:
			if line.strip() == "\t".join(vind):
				vtask = 1
			elif vtask == 1 and line.strip():
				vgene = line.split("\t")[1]
				vgene = "vir|" + vgene.split("|")[0]
				if vgene.strip() not in vlist:
					vlist.append(vgene.strip())
			elif vtask == 1 and not line.strip():
				vtask = 0
			elif line.strip() == "\t".join(aind):
				atask = 1
			elif atask == 1 and line.strip():
				agene = line.split("\t")[1]
				agene = "amr|" + agene.split("|")[0]
				if agene.strip() not in alist:
					alist.append(agene.strip())
			elif atask == 1 and not line.strip():
				atask = 0
		infile.close()
	final_header = ["Genome"]
	final_header.extend(vlist)
	final_header.extend(alist)
	final_header.extend(["ANI_Species", "panC_Clade", "MLST_ST", "rpoB_AT", "16S_Species"])
	final_file = outdir + "btyper2matrix_output.txt"
	with open(final_file, "w") as outfile:
		print >> outfile, "\t".join(final_header)
	return(filelist, final_file, vlist, alist)

def parse_file(f, outfile, vlist, alist):

	genome = f.split("/")[-1].replace("_final_results.txt", "").strip()
	vind = ["Hit #","Virulence Gene Name","E-Value Percent (%) Identity","Percent (%) Coverage"]
	aind = ["Hit #","AMR Gene Name","E-Value Percent (%) Identity","Percent (%) Coverage"]
	bind = ["Most Similar Reference Genome", "ANI", "Coverage"]
	pind = ["panC Clade Name","Closest Strain","Percent (%) Identity","Percent (%) Coverage"]
	mind = ["ST","glp","gmk","ilv","pta","pur","pyc","tpi"]
	rind = ["Predicted rpoB Allelic Type", "Percent (%) Identity", "Percent (%) Coverage"]
	sind = ["Predicted 16s Type", "Percent (%) Identity", "Percent (%) Coverage"]
	vtask, atask, btask, ptask, mtask, rtask, stask = 0, 0, 0, 0, 0, 0, 0
	vgenes, agenes = [], []
	bval, pval, mval, rval, sval = "NA", "NA", "NA", "NA", "NA"
	infile = open(f, "r")
	for line in infile:
		if line.strip() == "\t".join(vind):
			vtask = 1
		elif vtask == 1 and line.strip():
			vgene = line.split("\t")[1]
			vgene = "vir|" + vgene.split("|")[0]
			vgenes.append(vgene.strip())
		elif vtask == 1 and not line.strip():
			vtask = 0
		elif line.strip() == "\t".join(aind):
			atask = 1
		elif atask == 1 and line.strip():
			agene = line.split("\t")[1]
			agene = "amr|" + agene.split("|")[0]
			agenes.append(agene.strip())
		elif atask == 1 and not line.strip():
			atask = 0
		elif line.strip() == "\t".join(bind):
			btask = 1
		elif btask == 1 and line.strip() and "\t" in line.strip():
			bval = line.split("\t")[0].strip()
		elif btask == 1 and not line.strip():
			btask = 0
		elif line.strip() == "\t".join(pind):
			ptask = 1
		elif ptask == 1 and line.strip() and "\t" in line.strip():
			pval = line.split("\t")[0].strip()
		elif ptask == 1 and not line.strip():
			ptask = 0
		elif line.strip() == "\t".join(mind):
			mtask = 1
		elif mtask == 1 and line.strip() and "\t" in line.strip():
			mval = line.split("\t")[0].strip()
		elif mtask == 1 and not line.strip():
			mtask = 0
		elif line.strip() == "\t".join(rind):
			rtask = 1
		elif rtask == 1 and line.strip() and "\t" in line.strip():
			rval = line.split("\t")[0]
			rval = rval.split("|")[1].strip()
			if "*" in line:
				rval = rval+"*"
		elif rtask == 1 and not line.strip():
			rtask = 0
		elif line.strip() == "\t".join(sind):
			stask = 1
		elif stask == 1 and line.strip() and "\t" in line.strip():
			sval = line.split("\t")[0].strip()
		elif stask == 1 and not line.strip():
			stask = 0
	infile.close()
	final_line = [genome]	
	if vlist:	
		for v in vlist:
			if v in vgenes:
				final_line.append("1")
			else:
				final_line.append("0")
	if alist:
		for a in alist:
			if a in agenes:
				final_line.append("1")
			else:
				final_line.append("0")
	final_line.append(bval)
	final_line.append(pval)
	final_line.append(mval)
	final_line.append(rval)
	final_line.append(sval)	
	with open(outfile, "a") as finalout:
		print >> finalout, "\t".join(final_line)		
		

def main():
	parser = argparse.ArgumentParser(usage = "btyper2matrix.py -i </path/to/directory/btyper_final_results/> -o </path/to/output/directory/>")

	parser.add_argument("-i", "--input", help = "Path to directory containing btyper final results files; these files have the suffix '_final_results.txt' and should be in a directory called 'btyper_final_results', provided the directory was not renamed", nargs = 1, required = True)

	parser.add_argument("-o", "--output", help = "Path to desired output directory where matrix will be deposited", nargs = 1, required = True)

	args = parser.parse_args()
	
	indir, outdir = get_args(args)[0], get_args(args)[1]

	filelist, final_file, vlist, alist = glob_files(indir, outdir)

	for f in filelist:
		parse_file(f, final_file, vlist, alist)

if __name__ == "__main__":
        main()

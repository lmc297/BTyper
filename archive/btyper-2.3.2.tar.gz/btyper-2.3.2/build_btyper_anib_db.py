#!/usr/bin/env python

import sys, os, argparse
from urllib2 import urlopen

def get_args(args):

	ani_directory = args.database[0]
	if ani_directory == "published":
		ani_size = "118M"
	elif ani_directory == "effective":
		ani_size = "237M"
	else:
		print  ani_directory + " does not exist. You must select either published or effective (published = 118M, effective = 237M)."
		print "Exiting..."
		sys.exit()
	print "You specified the '" + ani_directory + "' ANIb database. This database will take up " + ani_size + " of space on your computer. Do you want to continue? Type 'yes' and press ENTER to download the " + ani_directory + " database, or type any other key and press ENTER to exit without downloading the database."
	newmm=raw_input("Do you want to download the " + ani_directory + " ANIb database (" + ani_size + ")?: ")
	if newmm.replace("'","").replace('"',"").strip()!="yes":
		print "Exiting..."
		sys.exit()
	else:
		return(ani_directory)
				

def get_btyper_path():

	btyper_path = os.path.realpath(__file__)
        btyper_path = btyper_path.rpartition("/")[0].strip()+"/"
        return(btyper_path)


def download_genomes(btyper_path, genome_list, ani_directory):

        glist = open(genome_list, "r")
        for line in glist:
                if "#" not in line:
                        gname = line.split("\t")[0].strip()
                        gpath = line.split("\t")[1].strip()
                        if not os.path.isfile(btyper_path + "seq_anib_db/" + ani_directory + "/" +  gname):
				# read file in chunks
				# courtesy of Alex Martelli: https://stackoverflow.com/questions/1517616/stream-large-binary-files-with-urllib2-to-file
				response = urlopen(gpath)
				chunk_size = 16 * 1024
				print "Downloading " + gname + "..."
				with open(btyper_path + "seq_anib_db/" + ani_directory + "/" + gname + ".gz", "wb") as f:
					while True:
						chunk = response.read(chunk_size)
						if not chunk:
							break
						f.write(chunk)
				os.system("gunzip " + btyper_path + "seq_anib_db/" + ani_directory + "/" + gname)

def main():

        parser = argparse.ArgumentParser(usage = "build_btyper_anib_db.py -db [published or effective]")

        parser.add_argument("-db", "--database", help = "Specify the ANIb database to download for use with BTyper's -b/--anib option: published or effective; published for 118M database with 18 published Bacillus cereus group species, or effective for 237M database, which includes published database plus 21 effective Bacillus cereus group species that have been proposed in the literature but not published as a novel species (39 species total; for most users' purposes, the published database is recommended)", nargs = 1, required = True)
	
	btyper_path = get_btyper_path()

        args = parser.parse_args()
	
        ani_directory = get_args(args)	
	
	if ani_directory == "effective":
		genome_list = btyper_path + "seq_anib_db/effective/effective.txt"
		download_genomes(btyper_path, genome_list, ani_directory)
		genome_list = btyper_path + "seq_anib_db/published/published.txt"
		download_genomes(btyper_path, genome_list, "published")
	elif ani_directory == "published":
		genome_list = btyper_path + "seq_anib_db/published/published.txt"
		download_genomes(btyper_path, genome_list, "published")

if __name__ == "__main__":
        main()

